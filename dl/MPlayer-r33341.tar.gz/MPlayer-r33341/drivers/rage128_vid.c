#define RAGE128

#include "radeon_vid.c"
