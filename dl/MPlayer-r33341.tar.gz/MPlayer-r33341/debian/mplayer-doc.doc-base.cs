Document: mplayer-cs
Title: MPlayer documentation (Czech)
Author: The MPlayer team
Abstract: This documentation describes the use of MPlayer. (Czech)
 MPlayer is a movie player for GNU/Linux that supports a wide
 range of audio and video formats, and output drivers.
Section: Sound

Format: HTML
Index: /usr/share/doc/mplayer-doc/HTML/cs/index.html
Files: /usr/share/doc/mplayer-doc/HTML/cs/*.html
