#ifndef _RTSP_H
#define _RTSP_H

void rtsp_listen_loop(void);
void rtsp_shutdown_stream(void);

#endif // _RTSP_H
